console.log("this is external file");

// -> comment in js
/* 
sdfds
sdfd
sdfdf*/

// data types  : what is the type of are variable .
// /loat/double -> 2.24512545
var len = 5.5;
// 1. Number/INT
var length = 5;

// 2. Strings -> ""

var name = "NEHA";

// 3. Booleans :

var x = true;
var y = false;

// 4. Object : -> key : value

package_val = {
  start: "npm vite",
};

// 5. array : similar type of data ko store karta hai.... let say numeric, string.

const cars = ["nano", "maruti", "xyzzz"];

// 6. date object:
const date = new Date("2025-01-02");
console.log(date);
